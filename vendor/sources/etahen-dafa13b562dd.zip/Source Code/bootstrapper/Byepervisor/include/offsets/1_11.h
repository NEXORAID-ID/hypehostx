#ifndef OFFSETS_1_11_H
#define OFFSETS_1_11_H

uint64_t g_sym_map_111[] = {
    0x4ADF5B0,          // KERNEL_SYM_DMPML4I
    0x4ADF5B4,          // KERNEL_SYM_DMPDPI
    0x4ADF30C,          // KERNEL_SYM_PML4PML4I
    0x4ADF328,          // KERNEL_SYM_PMAP_STORE
    0x7980000,          // KERNEL_SYM_DATA_CAVE
    0x0044000,          // KERNEL_SYM_CODE_CAVE
    0x1CA2690,          // KERNEL_SYM_PS4_SYSENT
    0x1CAA890,          // KERNEL_SYM_PPR_SYSENT
    0x0042000,          // KERNEL_SYM_GADGET_JMP_PTR_RSI
};

uint64_t g_patch_map_111[] = {
    0x05A9C80,          // KERNEL_PATCH_HAS_MMAP_SELF_CAPABILITY
    0x05A9C90,          // KERNEL_PATCH_IS_ALLOWED_TO_MMAP_SELF
    0x0981A69,          // KERNEL_PATCH_MMAP_SELF_CALL_IS_LOADABLE
    0x02F1810,          // KERNEL_PATCH_SYS_GETGID
};

#endif // OFFSETS_1_11_H